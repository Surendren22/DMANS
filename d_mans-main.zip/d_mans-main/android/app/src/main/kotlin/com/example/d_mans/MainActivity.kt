package com.example.d_mans

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
