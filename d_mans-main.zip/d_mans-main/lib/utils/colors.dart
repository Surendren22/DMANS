import 'package:flutter/material.dart';

final mainColor = Color(0xff53B175);
final colorBlack = Colors.black;
final filledColor = Color(0xffD9D9D9);
final colorwhite = Colors.white;

//Animation
const kAnimationDuration = Duration(milliseconds: 200);
